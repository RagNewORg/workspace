package com.liferay.demo.twitterrule.content.targeting.rule;

import com.liferay.content.targeting.api.model.BaseRuleCategory;

public class TwitterSampleRuleCategory extends BaseRuleCategory {

	public static final String KEY = "twitter";

	@Override
	public String getCategoryKey() {
		return KEY;
	}

	@Override
	public String getIcon() {
		return "icon-twitter";
	}

	
}
